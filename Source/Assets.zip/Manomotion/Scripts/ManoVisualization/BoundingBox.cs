﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public struct BoundingBox
{
    public Vector3 top_left;
    public float width;
    public float height;
}